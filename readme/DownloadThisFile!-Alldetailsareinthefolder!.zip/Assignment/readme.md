There are html and css file given in the zip folder you have to use the html elements in your app and import css files.
The end result should look like the website when you open index.html

1. Initialize a Vite app or use Create React App
2. Create boilerplate - remove unnecessary code
3. Import the CSS files into your App.jsx
4. Create 3 Components for `header` `hero area` and `footer`.
5. Use those components in App.js